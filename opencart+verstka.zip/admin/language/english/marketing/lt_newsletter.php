<?php
// Heading
$_['heading_title']     = 'Newsletter Subscribers';

// Text
$_['text_success']      = 'Success: You have deleted newsletter subscribers!';
$_['text_list']         = 'Newsletter Subscribers List';

// Column
$_['column_id']         = 'Id';
$_['column_email']      = 'Email';

// Entry
$_['entry_email']       = 'Email Address';

// Button
$_['button_export']     = 'Export Subscribers List';

// Error
$_['error_permission']  = 'Warning: You do not have permission to modify marketing tracking!';