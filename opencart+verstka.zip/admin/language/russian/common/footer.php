<?php
// Text
$_['text_footer'] 	= '<HR><a href="http://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' Все права защищены.';
$_['text_version'] 	= 'Version %s (trs.2.0.3.0)';

