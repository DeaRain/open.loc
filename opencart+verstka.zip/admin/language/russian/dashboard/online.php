<?php
// Heading
$_['heading_title'] = 'Люди Online';

// Text
$_['text_view']     = 'подробнее...';

